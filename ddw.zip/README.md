# Tikloot

## what is this?

this is a toolkit for something like encryption,stream and so on

## how to import it into my project?

`maven` dependency:

```xml
<dependency>
    <groupId>io.github.kuomintang666</groupId>
    <artifactId>tikloot</artifactId>
    <version>your tikloot version</version>
</dependency>
```
I was upload it to maven central repository, maybe...

at least, maven tells me it uploaded it...

this project is developing, so it may have some bugs

if you have any question,`issue` please! ^v^

## how to use?

view `doc` pls->[tikloot document](https://kuomintang666.github.io/documents/tikloot/index.html)
